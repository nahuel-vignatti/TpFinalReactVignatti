import "./footer.css"

function Footer(){
    return(
        <h1>prueba footer</h1>
    )
}
export default Footer;